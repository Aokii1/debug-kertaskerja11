<!--Membuat sambungan ke db-->
<?php
//sila lengkapkan kod aturcara
$con=mysqli_connect("localhost", "root","","vaksin") or die("HAHAHAHAHHA ADA ERROR KE TUH");
?>

